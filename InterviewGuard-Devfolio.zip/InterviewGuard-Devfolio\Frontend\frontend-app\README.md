﻿# InterviewGuard — Frontend Application

Modern, dark-themed React + Vite single-page application for the InterviewGuard AI-assisted interview integrity platform.

---

## 🚀 Getting Started

### 1. Prerequisites
- Node.js 18+ (tested on Node.js 20 & 22)
- `npm` package manager

### 2. Install Dependencies
```bash
npm install
```

### 3. Run Development Server
```bash
npm run dev
```

The Vite dev server starts at `http://localhost:5173`.

### 4. Build for Production
```bash
npm run build
```

---

## 🧭 Application Navigation & Modes

1. **Dashboard (`/`)**:
   - Platform overview, high-level metrics, recent assessments list, and scoring model specifications.
2. **Unified Live Interview**:
   - AI interviewer on the left, candidate camera feed on the right.
   - 5 customized interview questions based on candidate role, skills, and experience.
   - Speech synthesis (AI asks questions aloud) and Speech-to-Text response capture.
   - 6 real-time monitoring cards powered by live frame sampling sent to backend YOLO + OpenCV models.
   - Automated session aggregation sent to `/analyze` on interview completion.
3. **Recorded Interview / Video Analysis**:
   - Drag-and-drop or file selector supporting `.mp4`, `.avi`, `.mov`, `.mkv`, and `.webm`.
   - Displays frame counts, person tracking, phone detection, and face visibility ratios.
4. **Analysis Result**:
   - Risk score gauge (`0–100`) and risk level badge (**LOW** / **MEDIUM** / **HIGH**).
   - 5-part category breakdown (+30 / +20 / +25 / +15 / +10).
   - Filtered evidence list and prescribed next action.
   - Visible human-review disclaimer.
5. **Demo Mode**:
   - 5 interactive synthetic scenarios running through the live `/analyze` backend endpoint.
6. **Test Lab**:
   - Automated verification suite validating all 5 synthetic test cases against required thresholds via `/test-lab/run`.

---

## 🔗 Backend Connection
The frontend connects to the FastAPI backend at `http://127.0.0.1:8000`. Ensure the backend server is running before launching full analysis sessions.
