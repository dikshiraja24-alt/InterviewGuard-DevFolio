﻿# InterviewGuard — Backend Service

FastAPI-powered interview integrity analysis engine utilizing YOLOv11 and OpenCV for real-time visual signal detection, speech response analysis, and cautious integrity scoring.

---

## 🚀 Getting Started

### 1. Prerequisites
- Python 3.10+ (tested on Python 3.10 – 3.14)
- `pip` package manager

### 2. Environment Setup
Create and activate a clean virtual environment:

```bash
# Windows
python -m venv venv
.\venv\Scripts\activate

# Linux / macOS
python3 -m venv venv
source venv/bin/activate
```

### 3. Install Dependencies
Install the required packages using `requirements.txt`:

```bash
pip install -r requirements.txt
```

### 4. Run the Server
Launch the FastAPI development server with Uvicorn:

```bash
uvicorn main:app --host 127.0.0.1 --port 8000 --reload
```

The API will be live at `http://127.0.0.1:8000`. Interactive OpenAPI documentation is accessible at `http://127.0.0.1:8000/docs`.

---

## 📡 API Endpoints

| Method | Endpoint | Description |
|---|---|---|
| `GET` | `/health` | Verifies YOLO model status, OpenCV Haar cascade, and service health. |
| `POST` | `/detect-frame` | Analyzes a single camera frame (JPEG/PNG) for person count, cell phones, and face visibility. |
| `POST` | `/analyze` | Comprehensive interview analysis evaluating candidate profile, 5 Q&A pairs, and aggregated live monitoring signals. |
| `POST` | `/analyze-video` | Upload recorded interview (`.mp4`, `.avi`, `.mov`, `.mkv`, `.webm`) for frame-sampled detection (~1 frame/sec). |
| `POST` | `/test-lab/run` | Executes the 5 calibrated synthetic test cases to verify scoring rules and thresholds. |

---

## ⚖️ Scoring Formula & Risk Tiers

Risk score is computed on a scale of **0 to 100** based on 5 explicit categories:
- **Skill Mismatch**: Max +30 points
- **Technical-Depth Mismatch**: Max +20 points
- **Profile Contradiction**: Max +25 points
- **Prompting / External Assistance**: Max +15 points
- **Observation Signals**: Strictly capped at **Max +10 points**

### Risk Tiers:
- **LOW (`0 – 29`)**: Normal alignment. Recommended action: *"Continue normal interviewer review."*
- **MEDIUM (`30 – 59`)**: Minor discrepancies. Recommended action: *"Perform manual verification and ask additional technical questions."*
- **HIGH (`60 – 100`)**: Noticeable signals. Recommended action: *"Perform detailed manual verification before making any hiring decision."*

---

## 🛡️ Important Design Guidelines

1. **Human-Assisted Review Only**:
   InterviewGuard is an assistive observation system designed for human interviewers. It **does not** make automated hiring or rejection decisions.
2. **Cautious Terminology**:
   Signals are labeled cautiously (e.g., *"Potential external-device signal detected"*).
3. **No OCR**:
   Optical Character Recognition (OCR) is intentionally omitted to avoid false positives, high computational overhead, and invasive background screen-scraping.
