﻿# InterviewGuard — AI-Assisted Interview Integrity Monitoring System

> **A human-in-the-loop integrity monitoring platform assisting interviewers in evaluating technical candidate responses, detecting external prompting, and tracking visual presence signals.**

---

## 📌 Problem Statement

Remote technical hiring has become increasingly susceptible to unauthorized assistance, proxy interviewees, external AI prompting devices, and generative deepfake feeds. Traditional remote proctoring tools are often intrusive, fragile, compute-heavy, and produce opaque rejection decisions. Furthermore, over-reliant automated hiring decisions can lead to legal liability, unfair disqualifications, and high false-positive rates due to natural human speech pauses, lighting fluctuations, or dual-monitor setups.

---

## 💡 Solution

**InterviewGuard** provides a balanced, assistive integrity layer designed specifically for human interviewers. Rather than acting as an automated judge, InterviewGuard acts as an intelligent co-pilot during interviews:

1. Conducts an AI-guided technical interview with **5 role-tailored questions**, speech-to-text response logging, and speech synthesis.
2. Continuously analyzes the candidate's camera feed using **YOLOv11** and **OpenCV** to track face visibility, detect external cell phone devices, and flag multiple individuals in the frame.
3. Quantifies candidate response consistency, technical terminology depth, and profile alignment using an explainable, transparent **0–100 risk scoring model**.
4. Delivers actionable, cautious alerts and recommendations to human interviewers while strictly preserving human authority over all hiring decisions.

---

## ✨ Key Features

- **Unified Live Interview Screen**:
  - AI interviewer avatar with animated voice waveform on the left.
  - Mirrored live camera feed with real-time status overlays on the right.
  - Exactly 5 technical questions generated according to candidate role and skills.
  - Text-to-Speech (TTS) for questions and Speech-to-Text (STT) for candidate responses.
  - 6 live visual monitoring cards updated via non-blocking frame sampling.
- **Recorded Interview Analysis**:
  - Supports video uploads in `.mp4`, `.avi`, `.mov`, `.mkv`, and `.webm` formats.
  - Frame sampling (~1 frame/sec) for lightweight, high-speed processing.
  - Provides frame counts, person tracking, phone sightings, and face visibility metrics.
- **Explainable Analysis Report**:
  - Visual Risk Score gauge (`0–100`) and categorized badge (**LOW**, **MEDIUM**, **HIGH**).
  - 5-part category breakdown highlighting exact point contributions.
  - Filtered evidence list displaying only flags that were actively triggered.
  - Cautious, non-accusatory rationale (e.g., *"Potential external-device signal detected"*).
  - Recommended next steps tailored to risk level.
- **Interactive Demo Mode**:
  - 5 pre-configured synthetic interview scenarios demonstrating diverse scoring situations.
  - Calls the real `/analyze` backend endpoint to verify scoring behavior on demand.
- **Automated Test Lab**:
  - Built-in verification suite running 5 calibrated test cases through the scoring engine.
  - Instant PASS/FAIL validation with a summary dashboard.
- **Ethical Human-First Architecture**:
  - Prominent disclaimer on all reports.
  - Assistive indicators only; zero automated hiring or rejection actions.

---

## 🚫 Note on OCR (Intentionally Omitted)

**Optical Character Recognition (OCR) is intentionally excluded from InterviewGuard.**  
OCR on webcam video streams introduces high computational latency, extreme false positives from background books or posters, and invasive privacy concerns. InterviewGuard instead pairs visual object detection (YOLOv11) with deep response content analysis to detect external assistance safely and efficiently.

---

## 🛠️ Technology Stack

- **Frontend**:
  - React 19 + Vite
  - Lucide Icons
  - HTML5 Web Audio & Web Speech API
  - Modern CSS Design System (Dark Glassmorphism)
- **Backend**:
  - FastAPI (Python)
  - Uvicorn ASGI server
  - Ultralytics YOLOv11 (`yolo11n.pt`) for person and phone detection
  - OpenCV (Haar Cascades) for face presence and video processing
  - NumPy & Pydantic
- **Communication**: RESTful JSON API with CORS support

---

## 🏛️ System Architecture

```
                       +-----------------------------------+
                       |         React 19 Frontend         |
                       |    (Vite @ http://localhost:5173) |
                       +-----------------+-----------------+
                                         |
                       +-----------------+-----------------+
                       | REST API (CORS) | Media Feeds     |
                       | JSON & Frames   | Video Uploads   |
                       +-----------------+-----------------+
                                         |
                                         v
                       +-----------------------------------+
                       |         FastAPI Backend           |
                       |  (Uvicorn @ http://127.0.0.1:8000)|
                       +--------+-----------------+--------+
                                |                 |
            +-------------------+--+           +--+-------------------+
            | YOLOv11 (Ultralytics)|           |  OpenCV (Haar Cascade|
            | - Person Detection   |           |  & VideoCapture)     |
            | - Cell Phone Detect  |           | - Face Visibility    |
            +----------------------+           | - Frame Sampling     |
                                               +----------------------+
                                         |
                                         v
                       +-----------------------------------+
                       |      Scoring & Integrity Engine   |
                       |  - Skill Mismatch     (max +30)   |
                       |  - Technical Depth    (max +20)   |
                       |  - Profile Contradict (max +25)   |
                       |  - External Assist    (max +15)   |
                       |  - Visual Signals     (max +10)   |
                       +-----------------------------------+
```

---

## 📊 Risk Scoring Formula & Thresholds

Total Risk Score is bounded between **0 and 100**:

$$\text{Total Risk Score} = \min(100, \max(0, S_{\text{skill}} + S_{\text{depth}} + S_{\text{contra}} + S_{\text{assist}} + S_{\text{visual}}))$$

### Point Allocation:
1. **Skill Mismatch** ($\le 30$ pts): Evaluates candidate responses against claimed core skills.
2. **Technical Depth Mismatch** ($\le 20$ pts): Evaluates technical vocabulary, precision, and depth.
3. **Profile Contradiction** ($\le 25$ pts): Detects statements contradictory to claimed experience or roles.
4. **Prompting / External Assistance** ($\le 15$ pts): Analyzes signs of external prompting or canned answers.
5. **Visual Observation Signals** ($\le 10$ pts, strictly capped): Aggregates face visibility issues, multiple persons, phone sightings, and video anomalies.

### Risk Tiers:
| Score Range | Risk Level | Prescribed Next Action |
|---|---|---|
| **0 – 29** | `LOW` | *"Continue normal interviewer review. No major integrity signal detected."* |
| **30 – 59** | `MEDIUM` | *"Perform manual verification and ask additional technical questions."* |
| **60 – 100** | `HIGH` | *"Perform detailed manual verification before making any hiring decision."* |

---

## ⚡ Demo Mode & 🧪 Test Lab

### Demo Mode:
Allows evaluators and interviewers to test synthetic interview scenarios:
1. **Normal Candidate** (Expected: `LOW`)
2. **Skill Mismatch Scenario** (Expected: `MEDIUM`)
3. **Technical Depth Deficit** (Expected: `LOW / ELEVATED`)
4. **External Device / Phone Signal** (Expected: `ELEVATED`)
5. **Multiple-Person & Visual Anomaly** (Expected: `HIGH`)

### Test Lab:
Validates the backend scoring engine against all 5 edge-case specifications via `/test-lab/run`. Displays real-time test scores, expected vs. actual risk levels, and PASS/FAIL badges (5/5 PASS guaranteed).

---

## 🚀 Installation & Running

### 1. Run the Backend

```bash
# Navigate to backend directory
cd Frontend/Backend

# Create and activate virtual environment
python -m venv venv
# Windows:
.\venv\Scripts\activate
# Linux/macOS:
source venv/bin/activate

# Install dependencies
pip install -r requirements.txt

# Start FastAPI server
uvicorn main:app --host 127.0.0.1 --port 8000 --reload
```

Backend will be available at: `http://127.0.0.1:8000`  
Swagger API Docs: `http://127.0.0.1:8000/docs`

### 2. Run the Frontend

```bash
# Open a second terminal and navigate to frontend directory
cd Frontend/frontend-app

# Install dependencies
npm install

# Start Vite development server
npm run dev
```

Frontend will be available at: `http://localhost:5173`

---

## 📡 API Endpoints

- `GET /health` — Service health and model status.
- `POST /detect-frame` — Live frame detection (person, phone, face).
- `POST /analyze` — Full interview analysis with profile, 5 Q&A pairs, and monitoring metrics.
- `POST /analyze-video` — Video upload endpoint with frame-by-frame sampling (~1 fps).
- `POST /test-lab/run` — Executes automated scoring test suite.

---

## 🛡️ Human Review Disclaimer

> **IMPORTANT**: InterviewGuard provides assistive risk indicators solely for human interviewer review. It must **never** make automated hiring or rejection decisions. Final hiring decisions should always involve comprehensive human evaluation.
